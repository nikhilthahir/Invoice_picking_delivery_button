# -*- coding: utf-8 -*-
{
    'name': "invoice_delivery_button",

    'summary': "Generate stock picking from customer invoices.",

    'description': """
Generate stock picking from customer invoices.
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",


    'category': 'Uncategorized',
    'version': '0.1',


    'depends': ['base', 'account', 'stock', 'product'],


    'data': [
        # 'security/ir.model.access.csv',
        'views/account_move_views.xml',
    ],
}

