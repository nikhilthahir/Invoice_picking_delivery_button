from odoo import fields, models, api
from odoo.exceptions import UserError


class AccountMove(models.Model):
    _inherit = "account.move"

    delivery_count = fields.Integer(string='Delivery Orders', compute='_compute_picking')

    def action_create_picking(self):

        picking_type = self.env.ref('stock.picking_type_out')  
        if not picking_type:
            raise UserError('Picking type not found')


        picking = self.env["stock.picking"].create({
            "partner_id": self.partner_id.id,
            "scheduled_date": self.invoice_date,
            "date_deadline": self.invoice_date_due,
            "origin": self.name,
            "move_type": "direct",
            "picking_type_id": picking_type.id,
            "location_id": self.env.ref('stock.stock_location_stock').id,
            "location_dest_id": self.partner_id.property_stock_customer.id,
        })


        StockMove = self.env["stock.move"]
        for line in self.invoice_line_ids:
            StockMove.create({
                "name": line.name,
                "date": line.date,
                "product_uom": line.product_id.uom_id.id,
                "picking_id": picking.id,
                "product_id": line.product_id.id,
                "location_id": self.env.ref('stock.stock_location_stock').id,
                "location_dest_id": self.partner_id.property_stock_customer.id,
            })

        return picking

    @api.depends('invoice_line_ids')
    def _compute_picking(self):
        for order in self:

            pickings = self.env['stock.picking'].search([('origin', '=', order.name)])
            order.delivery_count = len(pickings)

    def action_view_delivery(self):

        return {
            "name": "Delivery",
            "type": "ir.actions.act_window",
            "res_model": "stock.picking",
            "view_mode": "tree,form",
            "domain": [('origin', '=', self.name)],
        }
